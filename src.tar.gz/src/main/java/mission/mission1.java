package mission;

public class mission1 {

    public static final int[] UPVAL = { 5, 50, 500, 5000, 50000, 500000, 5000000 };
    public static final int[] ROUND = { 10, 100, 1000, 10000, 100000, 1000000, 10000000 };

    public static int countNum(int a) {
        return String.valueOf( a ).length();
    }

    public static int round(int a, int b, int c) {
        return (((a+b)/c)*c);
    }
    public static int roundMax(int a) {
        int result = 0;
        int maxval = a;
        int c = countNum(a);
        if (c > 7) return a; 
        for( int i=0; i < c; i++) {
            result = round(a, UPVAL[i], ROUND[i]);
            if(result > maxval) maxval = result;
        }
        if(maxval>a) return roundMax(maxval);
        else return maxval;
    }
}