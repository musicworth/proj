package mission;

import org.junit.Test;
import static org.junit.Assert.*;

public class mission1Test {
    @Test
    public void testRoundMax1() {
        assertEquals(2, mission1.roundMax(2));
    }
    @Test
    public void testRoundMax2() {
        assertEquals(10, mission1.roundMax(5));
    }
    @Test
    public void testRoundMax3() {
        assertEquals(41, mission1.roundMax(41));
    }
    @Test
    public void testRoundMax4() {
        assertEquals(40, mission1.roundMax(36));
    }
    @Test
    public void testRoundMax5() {
        assertEquals(100, mission1.roundMax(46));
    }
    @Test
    public void testRoundMax6() {
        assertEquals(144, mission1.roundMax(144));
    }
    @Test
    public void testRoundMax7() {
        assertEquals(200, mission1.roundMax(146));
    }
    @Test
    public void testRoundMax8() {
        assertEquals(444, mission1.roundMax(444));
    }
    @Test
    public void testRoundMax9() {
        assertEquals(1000, mission1.roundMax(445));
    }
    @Test
    public void testRoundMax10() {
        assertEquals(400, mission1.roundMax(354));
    }
    @Test
    public void testRoundMax11() {
        assertEquals(1000, mission1.roundMax(454));
    }
    @Test
    public void testRoundMax12() {
        assertEquals(1000, mission1.roundMax(544));
    }
    @Test
    public void testRoundMax13() {
        assertEquals(400000, mission1.roundMax(354454));
    }
    @Test
    public void testRoundMax14() {
        assertEquals(1000000, mission1.roundMax(545454));
    }
    @Test
    public void testRoundMax15() {
        assertEquals(1000000, mission1.roundMax(444445));
    }
    @Test
    public void testRoundMax16() {
        assertEquals(4444444, mission1.roundMax(4444444));
    }
    @Test
    public void testRoundMax17() {
        assertEquals(10000000, mission1.roundMax(5454545));
    }
    @Test
    public void testRoundMax18() {
        assertEquals(10000000, mission1.roundMax(4444445));
    }
    @Test
    public void testRoundMax19() {
        assertEquals(4444444, mission1.roundMax(4444444));
    }
    @Test
    public void testRound1() {
        assertEquals(0, mission1.round(2, 5, 10));
    }
    @Test
    public void testRound2() {
        assertEquals(10, mission1.round(6, 5, 10));
    }
    @Test
    public void testRound3() {
        assertEquals(50, mission1.round(52, 5, 10));
    }
    @Test
    public void testRound4() {
        assertEquals(60, mission1.round(56, 5, 10));
    }
    @Test
    public void testRound5() {
        assertEquals(0, mission1.round(47, 50, 100));
    }
    @Test
    public void testRound6() {
        assertEquals(100, mission1.round(57, 50, 100));
    }
    @Test
    public void testCount1() {
        assertEquals(1, mission1.countNum(5));
    }
    @Test
    public void testCount2() {
        assertEquals(2, mission1.countNum(14));
    }
    @Test
    public void testCount3() {
        assertEquals(3, mission1.countNum(404));
    }
    @Test
    public void testCount4() {
        assertEquals(4, mission1.countNum(1234));
    }
    @Test
    public void testCount5() {
        assertEquals(5, mission1.countNum(43561));
    }
    @Test
    public void testCount6() {
        assertEquals(6, mission1.countNum(914034));
    }
}